const express = require("express");
const User = require("../models/Users");
const router = express.Router();

// Create User
router.post("/", (req, res) => {
  const user = User(req.body);
  user.save();
});

module.exports = router;
